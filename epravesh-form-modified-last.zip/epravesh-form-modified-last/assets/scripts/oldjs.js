var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the crurrent tab

function showTab(n) {
    // This function will display the specified tab of the form...
    var x = document.getElementsByClassName("tab");
    x[n].style.display = "block";
    //... and fix the Previous/Next buttons:
    if (n == 0) {
        document.getElementById("prevBtn").style.display = "none";
    } else {
        document.getElementById("prevBtn").style.display = "inline";
    }
    if (n == (x.length - 1)) {
        document.getElementById("nextBtn").innerHTML = "Submit";
    } else {
        document.getElementById("nextBtn").innerHTML = "Next";
    }
    //... and run a function that will display the correct step indicator:
    fixStepIndicator(n)
}

function nextPrev(n) {
    // This function will figure out which tab to display
    var x = document.getElementsByClassName("tab");
    // Exit the function if any field in the current tab is invalid:
    if (n == 1 && !validateForm()) return false;
    // Hide the current tab:
    x[currentTab].style.display = "none";
    // Increase or decrease the current tab by 1:
    currentTab = currentTab + n;
    // if you have reached the end of the form...
    if (currentTab >= x.length) {
        // ... the form gets submitted:
        document.getElementById("regForm").submit();
        return false;
    }
    // Otherwise, display the correct tab:
    showTab(currentTab);
}
/*
function myfun() {
    var selectone = document.getElementById('sel1').value(); // or in jQuery use: select = this;
    if(selectone.value) {
        // value is set to a valid option, so submit form
        return true;
    }else{
        return false;
    }//
    var error = 0;
    var sell1 = $('#sel1').val();

    if (sell1 == '0') {
        error = 1;
        alert('You should select a course');
    }

    if (error) {
        return false;
    } else {
        return true;
    }


}*/




function validateForm() {
    /*
        if(!this.form.checkbox.checked)
        {
            alert('You must agree to the terms first.');
            return false;
        }*/




    // This function deals with validation of the form fields
    var x, y, i, valid = true;
    x = document.getElementsByClassName("tab");
    y = x[currentTab].getElementsByClassName("inputone");
    /*
     y = x[currentTab].querySelectorAll("input[type=text], input[type=checkbox], input[type=radio]");
    if(!x[currentTab].input([type='checkbox']).checked)
    {
        alert('You must agree to the terms first.');
        return false;
    }*/


    /*if($('input[type=checkbox].checked'))
    {
        alert('You must agree to the terms first.');
        return false;
    }else {
        return true;
    }

    if(x[currentTab]==1){
        var error = 0;
        var sell1 = $('#sel1').val();

        if (sell1 ==0) {
            error = 1;
            alert('You should select a course');
        }

        if (error==1) {
            return false;
        } else {
            return true;
        }
    }

    */



    // A loop that checks every input field in the current tab:
    for (i = 0; i < y.length; i++) {
        if (y[i].value =="") {
            // add an "invalid" class to the field:
            y[i].className += " invalid";
            // and set the current valid status to false
            valid = false;
        }
        /*
        if(y[i].getElementsByTagName("select")){
            var error = 0;
            var sele = $('.sel11').val();

            if (sele =='0') {
                error = 1;
                alert('You should select a course');
            }

            if (error==1) {
                return false;
            } else {
                return true;
            }

        }else {
            /*
            if (y[i].getElementsByClassName("inputone").value=== "") {
                // add an "invalid" class to the field:
                y[i].className += " invalid";
                // and set the current valid status to false
                valid = false;
            }

        }*/

        /*
         // If a field is empty...
         if (y[i].value == "") {
             // add an "invalid" class to the field:
             y[i].className += " invalid";
             // and set the current valid status to false
             valid = false;
         }*/
    }
    // If the valid status is true, mark the step as finished and valid:
    if (valid) {
        document.getElementsByClassName("step")[currentTab].className += " finish";
    }
    return valid; // return the valid status
}



function fixStepIndicator(n) {
    // This function removes the "active" class of all steps...
    var i, x = document.getElementsByClassName("step");
    for (i = 0; i < x.length; i++) {
        x[i].className = x[i].className.replace(" active", "");
    }
    //... and adds the "active" class on the current step:
    x[n].className += " active";
}

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();

    $('.inputone').on('keypress', function (event) {
        var regex = new RegExp("^[a-zA-Z0-9@]+$");
        var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
        if (!regex.test(key)) {
            event.preventDefault();
            return false;
        }
    });

    /*$('.step.control-icon').removeClass('.active');*/
    $("input").val("");

    $(".input-effect input").focusout(function(){
        if($(this).val() != ""){
            $(this).addClass("has-content");
        }else{
            $(this).removeClass("has-content");
        }
    })

});

function selection(){

    var error = 0;
    var country = $('#sel1').val();

    if (country == '0') {
        error = 1;
        alert('You should select a country.');
    }

    if (error) {
        return false;
    } else {
        return true;
    }


}

/*-----------------------------------------------------------old-js-2------------------------------------------------------------*/
var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the crurrent tab

function showTab(n) {
    // This function will display the specified tab of the form...
    var x = document.getElementsByClassName("tab");
    x[n].style.display = "block";
    //... and fix the Previous/Next buttons:
    if (n == 0) {
        document.getElementById("prevBtn").style.display = "none";
    } else {
        document.getElementById("prevBtn").style.display = "inline";
    }
    if (n == (x.length - 1)) {
        document.getElementById("nextBtn").innerHTML = "Submit";
    } else {
        document.getElementById("nextBtn").innerHTML = "Next";
    }
    //... and run a function that will display the correct step indicator:
    fixStepIndicator(n)
}

function nextPrev(n) {
    // This function will figure out which tab to display
    var x = document.getElementsByClassName("tab");
    // Exit the function if any field in the current tab is invalid:
    if ((n == 1) && !validateForm(currentTab)) return false;
    // Hide the current tab:
    x[currentTab].style.display = "none";
    // Increase or decrease the current tab by 1:
    currentTab = currentTab + n;
    // if you have reached the end of the form...
    if (currentTab >= x.length) {
        // ... the form gets submitted:
        document.getElementById("regForm").submit();
        return false;
    }
    // Otherwise, display the correct tab:
    showTab(currentTab);
}
/*
function myfun() {
    var selectone = document.getElementById('sel1').value(); // or in jQuery use: select = this;
    if(selectone.value) {
        // value is set to a valid option, so submit form
        return true;
    }else{
        return false;
    }//
    var error = 0;
    var sell1 = $('#sel1').val();

    if (sell1 == '0') {
        error = 1;
        alert('You should select a course');
    }

    if (error) {
        return false;
    } else {
        return true;
    }


}*/

/*
if($('.tab').getElementsByClassName("inputone")){
    if($('input[name=optradio]:checked').length<=0)
    {
        alert("No radio checked")
    }else{

    }
}*/


function validateForm(currentTab) {
    /*
        if(!this.form.checkbox.checked)
        {
            alert('You must agree to the terms first.');
            return false;
        }*/




    // This function deals with validation of the form fields
    var x, y, i, valid = true;
    x = document.getElementsByClassName("tab");
    y = x[currentTab].getElementsByClassName("inputone");
    /*
     y = x[currentTab].querySelectorAll("input[type=text], input[type=checkbox], input[type=radio]");
    if(!x[currentTab].input([type='checkbox']).checked)
    {
        alert('You must agree to the terms first.');
        return false;
    }*/



    /*
if(x[currentTab ].getElementsByClassName('radio')){
if($('input[name=optradio]:checked').length<=0)
{
    alert("No radio checked")
}else{

}
}*/

    /*
if($('input[type=email]').hasClass('mail-box')){
    var value = $('.mail-box').val();
    var validate = validateEmail(value);
    if (!validate) {
        $(this).addClass('invalid');
        valid = false;
        return valid;
    } else {
        $(this).css('color', '#000');

    }
}

var validateEmail = function(elementValue) {
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    return emailPattern.test(elementValue);
}
function validateEmail(value) {
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    return emailPattern.test(value);
}*/

    $('.mail-box').keyup(function () {
        var value = $(this).val();
        var validate = validateEmail(value);
        if (!validate) {
            $(this).addClass('invalid');
            valid = false;
            return valid;
        } else {
            $(this).css('color', '#000');
            valid = true;
        }
    });

    var validateEmail = function(elementValue) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        return emailPattern.test(elementValue);
    }

    // A loop that checks every input field in the current tab:
    for (i = 0; i < y.length; i++) {
        if (y[i].value =="") {
            // add an "invalid" class to the field:
            y[i].className += " invalid";
            // and set the current valid status to false
            valid = false;
        }

        /*
                if(y[i].getElementsByClassName('mail-box')){
                    var value = $('.mail-box').val();
                    var validate = validateEmail(value);
                    if(!validate) {
                        valid = false;

                    } else {
                        valid = true;
                    }

                }else{
                    valid=true;
                    return valid;
                }
                function validateEmail(value){
                    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
                    return emailPattern.test(value);
                }*/

        /*
        $('.mail-box').keyup(function () {
            var value = $(this).val();
            var validate = validateEmail(value);
            if (!validate) {
                $(this).addClass('invalid');
                valid = false;
            } else {
                $(this).css('color', '#000');
                valid = true;
            }
        });

        var validateEmail = function(elementValue) {
            var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
            return emailPattern.test(elementValue);
        }*/


        if(y[i].getElementsByTagName("select")){
            var error = 0;
            var sele = $('.sel11').val();

            if (sele =='0') {
                error = 1;
                alert('You should select a course');
            }

            if (error==1) {
                return false;
            } else {
                /*return true;*/
                /*
                if (y[i].getElementsByClassName("inputone").value=== "") {


                    // add an "invalid" class to the field:
                    y[i].className += " invalid";
                    // and set the current valid status to false
                    valid = false;
                }*/
                /*
                if(y[i].getElementsByClassName("radio")){
                    if($('input[name=optradio]:checked').length<=0)
                    {
                        alert("No radio checked")
                    }
                }*/


                /*
                $('.mail-box').keyup(function () {
                    var value = $(this).val();
                    var validate = validateEmail(value);
                    if (!validate) {

                        $(this).addClass('invalid');
                        valid = false;
                    } else {
                        $(this).css('color', '#000');
                        valid = true;
                    }
                });

                var validateEmail = function(elementValue) {
                    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
                    return emailPattern.test(elementValue);
                }*/
            }

        }else {



        }


        /*
         // If a field is empty...
         if (y[i].value == "") {
             // add an "invalid" class to the field:
             y[i].className += " invalid";
             // and set the current valid status to false
             valid = false;
         }*/
    }





    // If the valid status is true, mark the step as finished and valid:
    if (valid==true) {
        document.getElementsByClassName("step")[currentTab].className += " finish";
    }
    return valid; // return the valid status
}



function fixStepIndicator(n) {
    // This function removes the "active" class of all steps...
    var i, x = document.getElementsByClassName("step");
    for (i = 0; i < x.length; i++) {
        x[i].className = x[i].className.replace(" active", "");
    }
    //... and adds the "active" class on the current step:
    x[n].className += " active";
}