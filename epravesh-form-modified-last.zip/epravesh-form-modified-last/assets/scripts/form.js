$(function () {
   /* var currentTab = 0; // Current tab is set to be the first tab (0)
    showTab(currentTab);

    function showTab(n) {
        fixStepIndicator(n);
    }

    function fixStepIndicator(n) {
        // This function removes the "active" class of all steps...
        var i, x = document.getElementsByClassName("segment-controls-label");
        for (i = 0; i < x.length; i++) {
            x[i].className = x[i].className.replace("current", "");
        }
        //... and adds the "active" class on the current step:
        x[n].className += " current";
    }*/

    var $sections = $('.form-section');

    function navigateTo(index) {
        // Mark the current section with the class 'current'
        $sections
            .removeClass('current')
            .eq(index)
            .addClass('current');
        $('.segment-controls-label').removeClass('current')
            .eq(index)
            .addClass('current');
        // Show only the navigation buttons that make sense for the current section:
        $('.form-navigation .previous').toggle(index > 0);
        var atTheEnd = index >= $sections.length - 1;
        $('.form-navigation .next').toggle(!atTheEnd);
        /*if(atTheEnd <$sections.length - 1){
           if( atTheEnd[$sections.length - 1]){
               $('.form-navigation .next').replaceWith(form-navigation [type=submit]);
           }

        }*/

        $('.form-navigation [type=submit]').toggle(atTheEnd);
    }

    function curIndex() {
        // Return the current index by looking at which section has the class 'current'
        return $sections.index($sections.filter('.current'));
    }

    // Previous button is easy, just go back
    $('.form-navigation .previous').click(function() {
        navigateTo(curIndex() - 1);
    });

    // Next button goes forward iff current block validates
    $('.form-navigation .next').click(function() {

        $('.demo-form').parsley().whenValidate({
            group: 'block-' + curIndex()
        }).done(function() {
            navigateTo(curIndex() + 1);
        });
    });

    // Prepare sections by setting the `data-parsley-group` attribute to 'block-0', 'block-1', etc.
    $sections.each(function(index, section) {
        $(section).find(':input').attr('data-parsley-group', 'block-' + index);
    });
    navigateTo(0); // Start at the beginning
});