
/*
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();


    $(".input-effect input").focusout(function(){
        if($(this).val() != ""){
            $(this).addClass("has-content");
        }else{
            $(this).removeClass("has-content");
        }
    })

});*/

$( function() {
    /*$( document ).tooltip();*/
    $( document ).tooltip({
        position: {
            my: "center bottom",
            at: "center top",
            using: function( position, feedback ) {
                $( this ).css( position );
                $( "<div>" )
                    .addClass( "arrow" )
                    .addClass( feedback.vertical )
                    .addClass( feedback.horizontal )
                    .appendTo( this );
            }
        }
    });
} );


/*
function selection(){

        var error = 0;
        var country = $('#sel1').val();

        if (country == '0') {
            error = 1;
            alert('You should select a country.');
        }

        if (error) {
            return false;
        } else {
            return true;
        }


}*/


$(function() {
    /*
    $('input[type=date]').keydown(function (e) {
        var date = new Date($('#date-birth').val());
        var date2=new Date();
        day = date.getDate();
        month = date.getMonth() + 1;
        year = date.getFullYear();
        alert([day, month, year].join('/'));

        if(date2.getFullYear()>date.getFullYear()){
            alert("wrong");
        }
    });*/


    $("#date-birth").datepicker({
        maxDate: "-1d"
    });


    $('.txtNumeric').keydown(function (e) {

        if (e.shiftKey || e.ctrlKey || e.altKey) {

            e.preventDefault();

        } else {

            var key = e.keyCode;

            if (!((key == 8) ||(key==9) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {

                e.preventDefault();

            }

        }

    });


    $('.numberonly').keydown(function (e) {

        if (e.shiftKey || e.ctrlKey || e.altKey) {

            e.preventDefault();

        } else {

            var key = e.keyCode;

            if (((key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {

                e.preventDefault();

            }

        }

    });

/*
    $('.mail-box').keyup(function () {
        var value = $(this).val();
        var valid = validateEmail(value);
        if (!valid) {
            $(this).css('color', 'red');
        } else {
            $(this).css('color', '#000');
        }
    });

    var validateEmail = function(elementValue) {
        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        return emailPattern.test(elementValue);
    }*/


});